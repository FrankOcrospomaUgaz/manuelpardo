@extends('reports.layout', ['title' => $report['title']])

@section('content')
    <h1>{{ $report['title'] }}</h1>
    <p class="muted">{{ $report['legacy_form'] }} / {{ $report['legacy_report'] }}</p>

    @if ($error)
        <div class="alert">
            No se pudo ejecutar la consulta. Verifique la conexion SQL Server, el driver pdo_sqlsrv y que existan los procedimientos/tables legacy.
            <br>{{ $error }}
        </div>
    @endif

    <section class="panel">
        <form class="filters" action="{{ route('reports.run', $slug) }}" method="post">
            @csrf
            @foreach (($report['params'] ?? []) as $name => $field)
                @php
                    $value = old($name, $params[$name] ?? ($field['default'] ?? ''));
                    $type = $field['type'] ?? 'text';
                @endphp

                @if ($type === 'select')
                    <label>
                        {{ $field['label'] }}
                        <select name="{{ $name }}">
                            @foreach (($field['options'] ?? []) as $optionValue => $optionLabel)
                                <option value="{{ $optionValue }}" @selected((string) $value === (string) $optionValue)>{{ $optionLabel }}</option>
                            @endforeach
                        </select>
                    </label>
                @elseif ($type === 'checkbox')
                    <label>
                        {{ $field['label'] }}
                        <span class="checkbox">
                            <input type="hidden" name="{{ $name }}" value="0">
                            <input type="checkbox" name="{{ $name }}" value="1" @checked((bool) $value)>
                            Activo
                        </span>
                    </label>
                @else
                    <label>
                        {{ $field['label'] }}
                        <input
                            type="{{ $type }}"
                            name="{{ $name }}"
                            value="{{ $value }}"
                            @required($field['required'] ?? false)
                        >
                    </label>
                @endif
            @endforeach

            <div class="actions">
                <button type="submit">Consultar</button>
                @if ($rows !== [])
                    <a class="button secondary" href="{{ route('reports.export', array_merge(['slug' => $slug], $params)) }}">Exportar CSV</a>
                @endif
            </div>
        </form>
    </section>

    <section>
        @if ($rows === [])
            <div class="panel muted">Sin datos para mostrar.</div>
        @else
            <p class="muted">{{ count($rows) }} registros encontrados.</p>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            @foreach (array_keys($rows[0]) as $column)
                                <th>{{ $column }}</th>
                            @endforeach
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($rows as $row)
                            <tr>
                                @foreach ($row as $value)
                                    <td>{{ is_scalar($value) || $value === null ? $value : json_encode($value) }}</td>
                                @endforeach
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </section>
@endsection
