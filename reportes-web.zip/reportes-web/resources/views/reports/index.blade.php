@extends('reports.layout', ['title' => 'Reportes'])

@section('content')
    <h1>Reportes</h1>
    <p class="muted">Menu web equivalente al modulo de reportes del sistema de escritorio.</p>

    <section class="grid">
        @foreach ($reports as $slug => $report)
            <a class="card" href="{{ route('reports.show', $slug) }}">
                <strong>{{ $report['title'] }}</strong>
                <span class="muted">{{ $report['legacy_form'] }} / {{ $report['legacy_report'] }}</span>
            </a>
        @endforeach
    </section>
@endsection
