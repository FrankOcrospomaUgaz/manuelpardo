<?php $__env->startSection('content'); ?>
    <h1><?php echo e($report['title']); ?></h1>
    <p class="muted"><?php echo e($report['legacy_form']); ?> / <?php echo e($report['legacy_report']); ?></p>

    <?php if($error): ?>
        <div class="alert">
            No se pudo ejecutar la consulta. Verifique la conexion SQL Server, el driver pdo_sqlsrv y que existan los procedimientos/tables legacy.
            <br><?php echo e($error); ?>

        </div>
    <?php endif; ?>

    <section class="panel">
        <form class="filters" action="<?php echo e(route('reports.run', $slug)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = ($report['params'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $value = old($name, $params[$name] ?? ($field['default'] ?? ''));
                    $type = $field['type'] ?? 'text';
                ?>

                <?php if($type === 'select'): ?>
                    <label>
                        <?php echo e($field['label']); ?>

                        <select name="<?php echo e($name); ?>">
                            <?php $__currentLoopData = ($field['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($optionValue); ?>" <?php if((string) $value === (string) $optionValue): echo 'selected'; endif; ?>><?php echo e($optionLabel); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                <?php elseif($type === 'checkbox'): ?>
                    <label>
                        <?php echo e($field['label']); ?>

                        <span class="checkbox">
                            <input type="hidden" name="<?php echo e($name); ?>" value="0">
                            <input type="checkbox" name="<?php echo e($name); ?>" value="1" <?php if((bool) $value): echo 'checked'; endif; ?>>
                            Activo
                        </span>
                    </label>
                <?php else: ?>
                    <label>
                        <?php echo e($field['label']); ?>

                        <input
                            type="<?php echo e($type); ?>"
                            name="<?php echo e($name); ?>"
                            value="<?php echo e($value); ?>"
                            <?php if($field['required'] ?? false): echo 'required'; endif; ?>
                        >
                    </label>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="actions">
                <button type="submit">Consultar</button>
                <?php if($rows !== []): ?>
                    <a class="button secondary" href="<?php echo e(route('reports.export', array_merge(['slug' => $slug], $params))); ?>">Exportar CSV</a>
                <?php endif; ?>
            </div>
        </form>
    </section>

    <section>
        <?php if($rows === []): ?>
            <div class="panel muted">Sin datos para mostrar.</div>
        <?php else: ?>
            <p class="muted"><?php echo e(count($rows)); ?> registros encontrados.</p>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <?php $__currentLoopData = array_keys($rows[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($column); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e(is_scalar($value) || $value === null ? $value : json_encode($value)); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reports.layout', ['title' => $report['title']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Downloads\Fuente HUella Digital VI\reportes-web\resources\views\reports\show.blade.php ENDPATH**/ ?>