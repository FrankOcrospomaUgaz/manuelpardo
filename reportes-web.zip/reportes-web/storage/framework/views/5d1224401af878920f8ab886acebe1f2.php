<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'Reportes'); ?></title>
    <style>
        :root {
            --bg: #f7f8fb;
            --panel: #ffffff;
            --line: #d9dee8;
            --text: #1d2733;
            --muted: #667085;
            --accent: #146c94;
            --accent-dark: #0d4f6e;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            color: var(--text);
            background: var(--bg);
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14px;
        }
        header {
            background: #ffffff;
            border-bottom: 1px solid var(--line);
            padding: 14px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }
        header a { color: var(--accent); text-decoration: none; font-weight: 700; }
        main { max-width: 1280px; margin: 0 auto; padding: 24px; }
        h1 { margin: 0 0 8px; font-size: 24px; }
        .muted { color: var(--muted); }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 12px;
        }
        .card, .panel {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
        }
        .card {
            padding: 16px;
            display: block;
            color: inherit;
            text-decoration: none;
        }
        .card:hover { border-color: var(--accent); }
        .card strong { display: block; margin-bottom: 6px; }
        .panel { padding: 18px; margin-bottom: 18px; }
        form.filters {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 14px;
            align-items: end;
        }
        label { display: grid; gap: 6px; color: var(--muted); font-size: 12px; }
        input, select {
            width: 100%;
            border: 1px solid var(--line);
            border-radius: 6px;
            padding: 9px 10px;
            color: var(--text);
            background: #fff;
            min-height: 38px;
        }
        .checkbox { display: flex; align-items: center; gap: 8px; min-height: 38px; }
        .checkbox input { width: auto; min-height: auto; }
        .actions { display: flex; gap: 8px; flex-wrap: wrap; }
        button, .button {
            min-height: 38px;
            border: 1px solid var(--accent);
            border-radius: 6px;
            background: var(--accent);
            color: #fff;
            padding: 9px 14px;
            text-decoration: none;
            cursor: pointer;
            font-weight: 700;
        }
        .button.secondary { background: #fff; color: var(--accent); }
        .table-wrap {
            overflow: auto;
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #fff;
        }
        table { width: 100%; border-collapse: collapse; min-width: 800px; }
        th, td {
            border-bottom: 1px solid var(--line);
            padding: 9px 10px;
            text-align: left;
            white-space: nowrap;
        }
        th { background: #eef3f7; font-size: 12px; color: #344054; }
        tr:last-child td { border-bottom: 0; }
        .alert {
            border: 1px solid #d92d20;
            background: #fff3f1;
            color: #912018;
            border-radius: 8px;
            padding: 12px 14px;
            margin-bottom: 18px;
        }
        @media (max-width: 640px) {
            header { padding: 12px 16px; }
            main { padding: 16px; }
        }
    </style>
</head>
<body>
    <header>
        <a href="<?php echo e(route('reports.index')); ?>">Reportes Web</a>
        <span class="muted">Fuente Huella Digital VI</span>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\DELL\Downloads\Fuente HUella Digital VI\reportes-web\resources\views/reports/layout.blade.php ENDPATH**/ ?>