<?php $__env->startSection('content'); ?>
    <h1>Reportes</h1>
    <p class="muted">Menu web equivalente al modulo de reportes del sistema de escritorio.</p>

    <section class="grid">
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="card" href="<?php echo e(route('reports.show', $slug)); ?>">
                <strong><?php echo e($report['title']); ?></strong>
                <span class="muted"><?php echo e($report['legacy_form']); ?> / <?php echo e($report['legacy_report']); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reports.layout', ['title' => 'Reportes'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Downloads\Fuente HUella Digital VI\reportes-web\resources\views\reports\index.blade.php ENDPATH**/ ?>