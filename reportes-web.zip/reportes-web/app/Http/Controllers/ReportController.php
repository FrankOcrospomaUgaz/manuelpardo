<?php

namespace App\Http\Controllers;

use App\Services\LegacyReportService;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportController extends Controller
{
    public function __construct(private readonly LegacyReportService $reports)
    {
    }

    public function index()
    {
        return view('reports.index', [
            'reports' => $this->reports->reports(),
        ]);
    }

    public function show(string $slug)
    {
        return view('reports.show', [
            'slug' => $slug,
            'report' => $this->reports->find($slug),
            'rows' => [],
            'params' => [],
            'error' => null,
        ]);
    }

    public function run(Request $request, string $slug)
    {
        $report = $this->reports->find($slug);
        $params = $this->reports->normalizeParams($report, $request->all());

        try {
            $rows = $this->reports->run($slug, $request->all());
            $error = null;
        } catch (QueryException $exception) {
            $rows = [];
            $error = $exception->getMessage();
        }

        return view('reports.show', [
            'slug' => $slug,
            'report' => $report,
            'rows' => $rows,
            'params' => $params,
            'error' => $error,
        ]);
    }

    public function export(Request $request, string $slug): StreamedResponse
    {
        $report = $this->reports->find($slug);
        $rows = $this->reports->run($slug, $request->query());
        $filename = $slug.'-'.now()->format('Ymd-His').'.csv';

        return response()->streamDownload(function () use ($rows): void {
            $out = fopen('php://output', 'w');

            if ($rows !== []) {
                fputcsv($out, array_keys($rows[0]));

                foreach ($rows as $row) {
                    fputcsv($out, $row);
                }
            }

            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'X-Report-Title' => $report['title'],
        ]);
    }
}
