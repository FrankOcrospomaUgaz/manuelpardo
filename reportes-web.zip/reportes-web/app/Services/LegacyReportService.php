<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class LegacyReportService
{
    public function reports(): array
    {
        return config('reports');
    }

    public function find(string $slug): array
    {
        $report = $this->reports()[$slug] ?? null;

        if (! $report) {
            throw new InvalidArgumentException("Reporte no encontrado: {$slug}");
        }

        return $report;
    }

    public function run(string $slug, array $input): array
    {
        $report = $this->find($slug);
        $params = $this->normalizeParams($report, $input);

        if (isset($report['handler'])) {
            return $this->{$report['handler']}($params);
        }

        return $this->callProcedure($report['procedure'], array_values($params));
    }

    public function normalizeParams(array $report, array $input): array
    {
        $params = [];

        foreach ($report['params'] ?? [] as $name => $definition) {
            $type = $definition['type'] ?? 'text';
            $value = $input[$name] ?? ($definition['default'] ?? null);

            if ($type === 'checkbox') {
                $params[$name] = filter_var($value, FILTER_VALIDATE_BOOLEAN);
                continue;
            }

            if ($value === '' || $value === null) {
                $params[$name] = $this->emptyValueFor($type, $definition);
                continue;
            }

            $params[$name] = $type === 'number' ? (int) $value : $value;
        }

        return $params;
    }

    public function callProcedure(string $procedure, array $params = []): array
    {
        $placeholders = implode(', ', array_fill(0, count($params), '?'));
        $sql = trim("EXEC {$procedure} {$placeholders}");

        return $this->rowsToArrays(DB::select($sql, $params));
    }

    public function registroMarcaciones(array $p): array
    {
        $fechaFin = $p['fecha_fin'] ?: $p['fecha_inicio'];
        $hasTipoHora = (int) $p['id_tipo_hora'] > 0;
        $singleDay = $fechaFin === $p['fecha_inicio'];

        if ($singleDay && $hasTipoHora) {
            return $this->callProcedure('up_ReporteRegistroMarcacionDiaTipo', [
                $p['hora_inicio'], $p['hora_fin'], $p['fecha_inicio'], $p['id_trabajador'], $p['id_tipo_hora'],
            ]);
        }

        if ($singleDay) {
            return $this->callProcedure('up_ReporteRegistroMarcacionDia', [
                $p['hora_inicio'], $p['hora_fin'], $p['fecha_inicio'], $p['id_trabajador'],
            ]);
        }

        if ($hasTipoHora) {
            return $this->callProcedure('up_ReporteRegistroMarcacionFechaTipo', [
                $p['hora_inicio'], $p['hora_fin'], $p['fecha_inicio'], $fechaFin, $p['id_trabajador'], $p['id_tipo_hora'],
            ]);
        }

        return $this->callProcedure('up_ReporteRegistroMarcacionFecha', [
            $p['hora_inicio'], $p['hora_fin'], $p['fecha_inicio'], $fechaFin, $p['id_trabajador'],
        ]);
    }

    public function comparacionHoras(array $p): array
    {
        return match ($p['tipo']) {
            'asistencia' => $this->callProcedure('up_ReporteComparacionHoraTrabAsistencia', [
                $p['id_trabajador'], $p['id_grupo'], $p['fecha_inicio'], $p['fecha_fin'],
            ]),
            'listado' => $this->callProcedure('up_ReporteComparacionHoraTrabL', [
                $p['id_trabajador'], $p['fecha_inicio'], $p['fecha_fin'],
            ]),
            default => $this->callProcedure('up_ReporteComparacionHoraTrab', [
                $p['id_trabajador'], $p['fecha_inicio'], $p['fecha_fin'],
            ]),
        };
    }

    public function justificaciones(array $p): array
    {
        $procedure = $p['formato'] === 'listado'
            ? 'up_ReporteJustificacionTrabL'
            : 'up_ReporteJustificacionTrab';

        return $this->callProcedure($procedure, [
            $p['id_trabajador'], $p['id_grupo'], $p['id_motivo'], $p['fecha_inicio'], $p['fecha_fin'],
        ]);
    }

    public function noMarcaciones(array $p): array
    {
        $suffix = $p['formato'] === 'listado' ? 'L' : 'D';
        $base = match ($p['tipo']) {
            'entrada_salida' => 'up_ReporteRegistroNoMarcacionesES',
            'ambas' => 'up_ReporteRegistroNoMarcacionesAmbas',
            default => 'up_ReporteRegistroNoMarcaciones',
        };

        return $this->callProcedure($base.$suffix, [
            $p['id_trabajador'], $p['id_grupo'], $p['fecha_inicio'], $p['fecha_fin'],
        ]);
    }

    public function tardanzas(array $p): array
    {
        $procedure = $p['formato'] === 'listado'
            ? 'up_ReporteRecordTardanzasL'
            : 'up_ReporteRecordTardanzasD';

        return $this->callProcedure($procedure, [
            $p['id_trabajador'], $p['id_grupo'], $p['fecha_inicio'], $p['fecha_fin'], $this->toleranciaTardanza(),
        ]);
    }

    public function inasistencias(array $p): array
    {
        $procedure = match (true) {
            $p['solo_dia'] && $p['formato'] === 'listado' => 'up_ReporteRecordInasistenciasSoloDiaL',
            $p['solo_dia'] => 'up_ReporteRecordInasistenciasSoloDiaD',
            $p['formato'] === 'listado' => 'up_ReporteRecordInasistenciasL',
            default => 'up_ReporteRecordInasistenciasD',
        };

        return $this->callProcedure($procedure, [
            $p['id_trabajador'], $p['id_grupo'], $p['fecha_inicio'], $p['fecha_fin'],
        ]);
    }

    public function sobretiempos(array $p): array
    {
        $procedure = $p['formato'] === 'listado'
            ? 'up_ReporteRecordSobretiemposL'
            : 'up_ReporteRecordSobretiemposD';

        return $this->callProcedure($procedure, [
            $p['id_trabajador'], $p['id_grupo'], $p['fecha_inicio'], $p['fecha_fin'],
        ]);
    }

    public function detalleAsistencia(array $p): array
    {
        $procedure = match ($p['formato']) {
            'justificado' => 'up_ReporteDetalleAsistenciaxTrabajadorJust',
            'listado' => 'up_ReporteDetalleAsistenciaxTrabajadorL',
            default => 'up_ReporteDetalleAsistenciaxTrabajador',
        };

        return $this->callProcedure($procedure, [
            $p['fecha_inicio'], $p['fecha_fin'], $this->toleranciaTardanza(), $this->toleranciaJornadaIncompleta(), $p['id_trabajador'],
        ]);
    }

    public function bitacora(array $p): array
    {
        $query = DB::table('Bitacora');

        foreach (['usuario' => 'Usuario', 'tabla' => 'Tabla', 'operacion' => 'Operacion'] as $param => $column) {
            if ($p[$param] !== '') {
                $query->where($column, $p[$param]);
            }
        }

        if ($p['fecha_inicio'] !== '') {
            $query->where('Fecha', '>=', $p['fecha_inicio']);
        }

        if ($p['fecha_fin'] !== '') {
            $query->where('Fecha', '<=', $p['fecha_fin']);
        }

        return $this->rowsToArrays($query->orderByDesc('Fecha')->get()->all());
    }

    public function consolidadoTrabajador(array $p): array
    {
        $marcaciones = $this->callProcedure('up_BuscarMarcacionesTrabajador', [
            $p['id_trabajador'], $p['fecha_inicio'], $p['fecha_fin'],
        ]);

        $trabajador = $this->trabajador($p['id_trabajador']);
        $suspension = $this->firstRow($this->callProcedure('up_BuscarMinutoSuspensionTrabajador', [
            $p['id_trabajador'], $p['fecha_inicio'], $p['fecha_fin'],
        ]));

        $result = [
            'IdTrabajador' => $p['id_trabajador'],
            'Apellidos' => trim(($trabajador['Apellido'] ?? '').', '.ucwords(strtolower($trabajador['Nombre'] ?? ''))),
            'FID' => 0, 'FNRD' => 0, 'SPD' => (int) ($suspension['Cantidad'] ?? 0),
            'FIH' => 0, 'FNRH' => 0, 'SPH' => (float) ($suspension['Diferencia'] ?? 0),
            'FRD' => 0, 'FRH' => 0, 'TARDRD' => 0, 'TARDNRD' => 0,
            'TARDRH' => 0, 'TARDNRH' => 0, 'HORASTRAB' => 0, 'FJNRD' => 0,
            'FJNRH' => 0, 'JIRD' => 0, 'JIRH' => 0, 'JIINJD' => 0, 'JIINJH' => 0,
            'JIJUSTNRD' => 0, 'JIJUSTNRH' => 0, 'FJRD' => 0, 'FJRH' => 0,
        ];

        $holguraEntrada = $this->holgura('Entrada');
        $holguraSalida = $this->holgura('Salida');
        $ultimoFeriadoNoRemunerado = null;
        $ultimoFeriadoRemunerado = null;

        foreach ($marcaciones as $marcacion) {
            $fecha = $this->value($marcacion, 'Fecha', 'FECHA');
            $feriado = $this->feriado($fecha);
            $justificacion = $this->value($marcacion, 'IdJustificacion');
            $remunerada = $justificacion ? (bool) ($this->motivoJustificacion($justificacion)['Remunerada'] ?? false) : null;
            $ideal = $this->minutesBetween($this->value($marcacion, 'HoraIngresoIdeal'), $this->value($marcacion, 'HoraSalidaIdeal'));
            $entradaReal = $this->value($marcacion, 'HoraIngresoReal');
            $salidaReal = $this->value($marcacion, 'HoraSalidaReal');

            if ($feriado) {
                if ((bool) ($feriado['Remunerado'] ?? false)) {
                    $result['FRH'] += $ideal;
                    if ($ultimoFeriadoRemunerado !== $fecha) {
                        $result['FRD']++;
                        $ultimoFeriadoRemunerado = $fecha;
                    }
                } else {
                    $result['FNRH'] += $ideal;
                    if ($ultimoFeriadoNoRemunerado !== $fecha) {
                        $result['FNRD']++;
                        $ultimoFeriadoNoRemunerado = $fecha;
                    }
                }

                continue;
            }

            if (! $entradaReal || ! $salidaReal) {
                $keyD = $justificacion ? ($remunerada ? 'FJRD' : 'FJNRD') : 'FID';
                $keyH = $justificacion ? ($remunerada ? 'FJRH' : 'FJNRH') : 'FIH';
                $result[$keyD]++;
                $result[$keyH] += $ideal;
                continue;
            }

            $tarde = max(0, $this->minutesBetween($this->value($marcacion, 'HoraIngresoIdeal'), $entradaReal));
            $incompleta = max(0, $this->minutesBetween($salidaReal, $this->value($marcacion, 'HoraSalidaIdeal')));

            if ($tarde > $holguraEntrada) {
                $keyD = $justificacion ? ($remunerada ? 'TARDRD' : 'TARDNRD') : 'TARDNRD';
                $keyH = $justificacion ? ($remunerada ? 'TARDRH' : 'TARDNRH') : 'TARDNRH';
                $result[$keyD]++;
                $result[$keyH] += $tarde;
            }

            if ($incompleta > $holguraSalida) {
                $keyD = $justificacion ? ($remunerada ? 'JIRD' : 'JIJUSTNRD') : 'JIINJD';
                $keyH = $justificacion ? ($remunerada ? 'JIRH' : 'JIJUSTNRH') : 'JIINJH';
                $result[$keyD]++;
                $result[$keyH] += $incompleta;
            }

            $result['HORASTRAB'] += $this->minutesBetween($entradaReal, $salidaReal);
        }

        return [$result];
    }

    private function toleranciaTardanza(): int
    {
        $row = $this->firstRow($this->rowsToArrays(DB::select('SELECT TOP 1 ToleranciaTardanza FROM Cliente')));

        return (int) ($row['ToleranciaTardanza'] ?? 0);
    }

    private function toleranciaJornadaIncompleta(): int
    {
        $row = $this->firstRow($this->rowsToArrays(DB::select('SELECT TOP 1 ToleranciaJornadaIncompleta FROM Cliente')));

        return (int) ($row['ToleranciaJornadaIncompleta'] ?? 0);
    }

    private function holgura(string $descripcion): int
    {
        $row = $this->firstRow($this->callProcedure('up_BuscarHolgura', [$descripcion]));

        return (int) ($row['ValorMin'] ?? 0);
    }

    private function feriado(string $fecha): ?array
    {
        $row = DB::table('Feriado')
            ->select('IdFeriado', 'FechaFeriado', 'Remunerado')
            ->whereDate('FechaFeriado', $fecha)
            ->first();

        return $row ? (array) $row : null;
    }

    private function motivoJustificacion(int $id): array
    {
        return $this->firstRow($this->callProcedure('up_BuscarMotivoJustificacion', [$id]));
    }

    private function trabajador(int $id): array
    {
        $row = DB::table('Trabajador')->where('IdTrabajador', $id)->first();

        return $row ? (array) $row : [];
    }

    private function emptyValueFor(string $type, array $definition): mixed
    {
        return match ($type) {
            'number' => (int) ($definition['default'] ?? 0),
            'checkbox' => false,
            default => $definition['default'] ?? '',
        };
    }

    private function rowsToArrays(array $rows): array
    {
        return array_map(fn ($row) => (array) $row, $rows);
    }

    private function firstRow(array $rows): array
    {
        return $rows[0] ?? [];
    }

    private function value(array $row, string ...$keys): mixed
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $row)) {
                return $row[$key];
            }
        }

        return null;
    }

    private function minutesBetween(mixed $start, mixed $end): int
    {
        if (! $start || ! $end) {
            return 0;
        }

        return (int) Carbon::parse($start)->diffInMinutes(Carbon::parse($end), false);
    }
}
